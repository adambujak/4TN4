data_extract.py imports training images and extracts features into csv file
train.py imports generated csv and shuffles the data-set and trains the model
reduce_noise.py imports the generated model and performs the proposed noise reduction on an image
error_calc.py performs error calculation of proposed method, noisy image, and mean filter compared to ground truth

